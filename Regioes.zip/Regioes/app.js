const listaEstado = require('./estados_cidades');

/*EXERCICIO 1 */
function getListaDeEstados(sigla) {
    const uf = sigla.estados.map((estado) =>{ 
        return estado.sigla} )
        console.log(`uf :`,uf)
        console.log('quantidade: ' ,listaEstado.estados.length);
} 

getListaDeEstados(listaEstado)

/*EXERCICIO 2 */
function getDadosEstado( valor) {
    lista = listaEstado.estados
    chave = "sigla"
    for (let i = 0; i < lista.length; i++) {
        const estado = lista[i];
        if (estado [chave] === valor) {
            return console.log('uf',[estado.sigla,estado.nome,estado.capital, estado.regiao]);
        }
    }
    return null;
}

getDadosEstado("AM")

function getCapitalEstado(valor) {
     lista = listaEstado.estados
     chave = "sigla"
     for (let i = 0; i < lista.length; i++) {
         const estado = lista[i];
         if (estado [chave] === valor) {
            return console.log('UF',[estado.sigla,estado.nome,estado.capital]);
       }
     }
     return null;
 }

getCapitalEstado("AC")

// /*function getEstadosRegiao (valor) {
    
//         lista = listaEstado.estados
//         chave = "regiao"
//         for (let i = 0; i< lista.length; i++) {
//             const estado = lista[i]
//             let imprimir = 0
//             if (estado[chave]===valor) {
//                 for (let index = 0; index < lista.length; index++) {
//                      imprimir=(
//                        {regiao: estado.regiao,
//                           estados: [{
    
//                           uf: estado.sigla,
//                             descricao: estado.nome,
//                         }]
//                         })
                   
//                 }
//                 console.log(imprimir);
//             }
//         }
//          return null
    
//     }*/
// // getEstadosRegiao("Sul")

// //Igual do professor usando map, e filter
// function getEstadosRegiao (regiao) {
//    const listaEstados = listaEstado.estados.filter(estado => estado.regiao === regiao);

//    const filtrando = {
//         regiao: regiao,
//         estados: listaEstados.map(estado => ({
//             uf : estado.sigla,
//             descricao:estado.capital
//         }))
//    };
//    console.log(filtrando);
// }
// getEstadosRegiao("Sul")

function getCapitalPais(capital) {
    const listaEstado = ListaEstados.estados.filter(estado => estado.capital_pais)

    const listando = {
        capitais:
            listaEstado.map(estado => ({
                capital_atual: estado.capital_pais.capital,
                uf: estado.sigla,
                descricao: estado.nome,
                capital: estado.capital,
                capital_pais_ano_inicio: estado.capital_pais.ano_inicio,
                capital_pais_ano_fim: estado.capital_pais.ano_fim

            }))
        
       
    }

    console.log(listando);
}
    
getCapitalPais()

function getDadosEstado( valor) {
       lista = listaEstado.estados
        chave = "sigla"
        const listaEstados = listaEstado.estados.filter(estado => estado.sigla === valor);
            
                const listando = {
                    cidades:
                        listaEstados.map(estado => ({
                          
                            uf: estado.sigla,
                            descricao: estado.nome,
                            capital: estado.capital,
                              cidades:estado.cidades,
                           
            
                        })) 

             }
              console.log(listando);
         }
        
     
getDadosEstado("AC")